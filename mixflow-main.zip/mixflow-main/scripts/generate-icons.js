#!/usr/bin/env node

/**
 * 图标生成脚本
 * 将SVG logo转换为各种尺寸的PNG图标
 * 
 * 使用方法:
 * 1. 安装依赖: npm install sharp
 * 2. 运行脚本: node scripts/generate-icons.js
 */

const fs = require('fs');
const path = require('path');

// 检查是否安装了sharp
try {
    require('sharp');
} catch (error) {
    console.log('❌ 需要安装 sharp 库来生成PNG图标');
    console.log('请运行: npm install sharp');
    process.exit(1);
}

const sharp = require('sharp');

const iconSizes = [
    { size: 16, name: 'favicon-16x16.png' },
    { size: 32, name: 'favicon-32x32.png' },
    { size: 192, name: 'android-chrome-192x192.png' },
    { size: 512, name: 'android-chrome-512x512.png' },
    { size: 180, name: 'apple-touch-icon.png' }
];

const inputSvg = path.join(__dirname, '../public/logo-detailed.svg');
const outputDir = path.join(__dirname, '../public/app-icons');

async function generateIcons() {
    try {
        // 确保输出目录存在
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }

        console.log('🎨 开始生成图标...');

        for (const icon of iconSizes) {
            const outputPath = path.join(outputDir, icon.name);

            await sharp(inputSvg)
                .resize(icon.size, icon.size)
                .png()
                .toFile(outputPath);

            console.log(`✅ 生成 ${icon.name} (${icon.size}x${icon.size})`);
        }

        // 生成favicon.ico (16x16)
        const faviconPath = path.join(__dirname, '../favicon.ico');
        await sharp(inputSvg)
            .resize(16, 16)
            .png()
            .toFile(faviconPath);

        console.log('✅ 生成 favicon.ico');
        console.log('🎉 所有图标生成完成！');

    } catch (error) {
        console.error('❌ 生成图标时出错:', error.message);
        process.exit(1);
    }
}

// 运行脚本
generateIcons();