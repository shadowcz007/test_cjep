# API速率限制开发计划 (SEC-001)

## 项目概述

**需求ID**: SEC-001  
**标题**: 实施API速率限制  
**优先级**: P0 (Must - 基本型)  
**RICE得分**: 9.0  
**关键依据**: 安全防护基础要求，防止滥用

## 技术背景分析

### 当前状态
- 使用 Next.js 14.0.4 App Router
- 已有API认证机制（API Key认证）
- 存在多个API端点：checklists、notes、file、image
- 缺乏速率限制保护，存在被滥用的风险

### 安全风险
1. **API滥用**: 无限制的API调用可能导致服务过载
2. **DDoS攻击**: 恶意用户可能发起大量请求
3. **资源消耗**: 大量并发请求消耗服务器资源
4. **数据泄露风险**: 高频请求可能被用于数据挖掘

### 现有API端点分析
- `/api/checklists` - 获取清单列表
- `/api/checklists/[listId]/items` - 清单项操作
- `/api/notes` - 笔记操作
- `/api/file/[username]/[filename]` - 文件下载
- `/api/image/[username]/[filename]` - 图片访问

## 开发计划

### 阶段一：基础速率限制框架 (3-5天)

#### 1.1 速率限制中间件开发
**目标**: 创建可复用的速率限制中间件

**任务清单**:
- [ ] 设计速率限制算法（令牌桶/滑动窗口）
- [ ] 实现内存存储的速率限制器
- [ ] 创建Redis存储的速率限制器（可选）
- [ ] 实现中间件装饰器

**新增文件**:
- `app/_server/utils/rate-limiter.ts` - 核心速率限制逻辑
- `app/_server/utils/rate-limit-middleware.ts` - 中间件实现
- `app/_server/types/rate-limit.ts` - 类型定义

#### 1.2 配置系统
**目标**: 建立灵活的速率限制配置

**任务清单**:
- [ ] 设计配置结构（不同端点不同限制）
- [ ] 实现环境变量配置
- [ ] 创建配置验证逻辑
- [ ] 添加配置热更新支持

**新增文件**:
- `app/_server/config/rate-limit-config.ts` - 配置管理
- `config/rate-limit.json` - 配置文件

### 阶段二：API端点集成 (2-3天)

#### 2.1 核心API端点保护
**目标**: 为所有API端点添加速率限制

**任务清单**:
- [ ] 集成checklists API速率限制
- [ ] 集成notes API速率限制
- [ ] 集成file API速率限制
- [ ] 集成image API速率限制
- [ ] 添加用户级别的速率限制

**修改文件**:
- `app/api/checklists/route.ts`
- `app/api/checklists/[listId]/items/route.ts`
- `app/api/notes/route.ts`
- `app/api/file/[username]/[filename]/route.ts`
- `app/api/image/[username]/[filename]/route.ts`

#### 2.2 认证集成
**目标**: 将速率限制与现有认证系统集成

**任务清单**:
- [ ] 基于API Key的速率限制
- [ ] 基于用户身份的速率限制
- [ ] 实现白名单机制
- [ ] 添加管理员豁免

**修改文件**:
- `app/_server/utils/api-helpers.ts`
- `app/_server/utils/api-auth.ts`

### 阶段三：监控和告警 (2天)

#### 3.1 监控系统
**目标**: 建立速率限制监控体系

**任务清单**:
- [ ] 实现请求计数统计
- [ ] 添加速率限制触发日志
- [ ] 创建监控仪表板
- [ ] 实现异常检测

**新增文件**:
- `app/_server/utils/rate-limit-monitor.ts` - 监控逻辑
- `app/_components/admin/RateLimitMonitor.tsx` - 监控界面

#### 3.2 告警机制
**目标**: 建立自动告警系统

**任务清单**:
- [ ] 实现阈值告警
- [ ] 添加邮件通知
- [ ] 创建Webhook通知
- [ ] 实现自动封禁机制

### 阶段四：测试和部署 (1-2天)

#### 4.1 测试
**任务清单**:
- [ ] 单元测试
- [ ] 集成测试
- [ ] 压力测试
- [ ] 安全测试

#### 4.2 部署
**任务清单**:
- [ ] 生产环境配置
- [ ] 监控部署
- [ ] 文档更新
- [ ] 用户通知

## 技术实现细节

### 1. 速率限制算法

#### 令牌桶算法实现
```typescript
// app/_server/utils/rate-limiter.ts
interface RateLimitConfig {
  windowMs: number;        // 时间窗口（毫秒）
  maxRequests: number;     // 最大请求数
  skipSuccessfulRequests?: boolean;
  skipFailedRequests?: boolean;
  keyGenerator?: (req: NextRequest) => string;
}

class TokenBucketRateLimiter {
  private buckets = new Map<string, TokenBucket>();
  
  async isAllowed(
    key: string, 
    config: RateLimitConfig
  ): Promise<{ allowed: boolean; remaining: number; resetTime: number }> {
    const bucket = this.getOrCreateBucket(key, config);
    return bucket.consume();
  }
  
  private getOrCreateBucket(key: string, config: RateLimitConfig): TokenBucket {
    if (!this.buckets.has(key)) {
      this.buckets.set(key, new TokenBucket(config));
    }
    return this.buckets.get(key)!;
  }
}

class TokenBucket {
  private tokens: number;
  private lastRefill: number;
  
  constructor(private config: RateLimitConfig) {
    this.tokens = config.maxRequests;
    this.lastRefill = Date.now();
  }
  
  consume(): { allowed: boolean; remaining: number; resetTime: number } {
    this.refill();
    
    if (this.tokens >= 1) {
      this.tokens--;
      return {
        allowed: true,
        remaining: this.tokens,
        resetTime: Date.now() + this.config.windowMs
      };
    }
    
    return {
      allowed: false,
      remaining: 0,
      resetTime: Date.now() + this.config.windowMs
    };
  }
  
  private refill() {
    const now = Date.now();
    const timePassed = now - this.lastRefill;
    const tokensToAdd = (timePassed / this.config.windowMs) * this.config.maxRequests;
    
    this.tokens = Math.min(this.config.maxRequests, this.tokens + tokensToAdd);
    this.lastRefill = now;
  }
}
```

### 2. 中间件实现

#### 速率限制中间件
```typescript
// app/_server/utils/rate-limit-middleware.ts
import { NextRequest, NextResponse } from "next/server";
import { TokenBucketRateLimiter } from "./rate-limiter";
import { getRateLimitConfig } from "../config/rate-limit-config";

const rateLimiter = new TokenBucketRateLimiter();

export function withRateLimit(
  config: RateLimitConfig,
  handler: (req: NextRequest) => Promise<NextResponse>
) {
  return async (req: NextRequest): Promise<NextResponse> => {
    const key = config.keyGenerator ? config.keyGenerator(req) : getDefaultKey(req);
    
    const result = await rateLimiter.isAllowed(key, config);
    
    if (!result.allowed) {
      return new NextResponse(
        JSON.stringify({ 
          error: "Too Many Requests",
          retryAfter: Math.ceil((result.resetTime - Date.now()) / 1000)
        }),
        {
          status: 429,
          headers: {
            "Content-Type": "application/json",
            "Retry-After": Math.ceil((result.resetTime - Date.now()) / 1000).toString(),
            "X-RateLimit-Limit": config.maxRequests.toString(),
            "X-RateLimit-Remaining": result.remaining.toString(),
            "X-RateLimit-Reset": result.resetTime.toString()
          }
        }
      );
    }
    
    const response = await handler(req);
    
    // 添加速率限制头信息
    response.headers.set("X-RateLimit-Limit", config.maxRequests.toString());
    response.headers.set("X-RateLimit-Remaining", result.remaining.toString());
    response.headers.set("X-RateLimit-Reset", result.resetTime.toString());
    
    return response;
  };
}

function getDefaultKey(req: NextRequest): string {
  const apiKey = req.headers.get("x-api-key");
  const ip = req.ip || req.headers.get("x-forwarded-for") || "unknown";
  
  return apiKey ? `api:${apiKey}` : `ip:${ip}`;
}
```

### 3. 配置管理

#### 速率限制配置
```typescript
// app/_server/config/rate-limit-config.ts
export interface RateLimitConfig {
  windowMs: number;
  maxRequests: number;
  skipSuccessfulRequests?: boolean;
  skipFailedRequests?: boolean;
  keyGenerator?: (req: NextRequest) => string;
}

export const RATE_LIMIT_CONFIGS = {
  // 通用API限制
  default: {
    windowMs: 15 * 60 * 1000, // 15分钟
    maxRequests: 100,
  },
  
  // 文件下载限制（更严格）
  fileDownload: {
    windowMs: 60 * 1000, // 1分钟
    maxRequests: 10,
  },
  
  // 图片访问限制
  imageAccess: {
    windowMs: 60 * 1000, // 1分钟
    maxRequests: 30,
  },
  
  // 数据操作限制
  dataOperation: {
    windowMs: 60 * 1000, // 1分钟
    maxRequests: 60,
  },
  
  // 管理员限制（更宽松）
  admin: {
    windowMs: 15 * 60 * 1000, // 15分钟
    maxRequests: 1000,
  }
};

export function getRateLimitConfig(endpoint: string, userRole?: string): RateLimitConfig {
  // 管理员用户使用更宽松的限制
  if (userRole === 'admin') {
    return RATE_LIMIT_CONFIGS.admin;
  }
  
  // 根据端点类型返回相应配置
  if (endpoint.includes('/file/') || endpoint.includes('/image/')) {
    return endpoint.includes('/image/') 
      ? RATE_LIMIT_CONFIGS.imageAccess 
      : RATE_LIMIT_CONFIGS.fileDownload;
  }
  
  if (endpoint.includes('/api/checklists') || endpoint.includes('/api/notes')) {
    return RATE_LIMIT_CONFIGS.dataOperation;
  }
  
  return RATE_LIMIT_CONFIGS.default;
}
```

### 4. API集成示例

#### 修改现有API端点
```typescript
// app/api/checklists/route.ts
import { withRateLimit } from "@/app/_server/utils/rate-limit-middleware";
import { getRateLimitConfig } from "@/app/_server/config/rate-limit-config";
import { withApiAuth } from "@/app/_server/utils/api-helpers";

export const dynamic = "force-dynamic";

async function handleGet(request: NextRequest) {
  return withApiAuth(request, async (user, req) => {
    // 现有逻辑
    const checklists = await getChecklistsForUser(user.username);
    return NextResponse.json({ checklists });
  });
}

// 应用速率限制
export const GET = withRateLimit(
  getRateLimitConfig('/api/checklists'),
  handleGet
);
```

### 5. 监控系统

#### 监控实现
```typescript
// app/_server/utils/rate-limit-monitor.ts
interface RateLimitMetrics {
  totalRequests: number;
  blockedRequests: number;
  topUsers: Array<{ key: string; requests: number }>;
  topEndpoints: Array<{ endpoint: string; requests: number }>;
}

class RateLimitMonitor {
  private metrics: RateLimitMetrics = {
    totalRequests: 0,
    blockedRequests: 0,
    topUsers: [],
    topEndpoints: []
  };
  
  recordRequest(key: string, endpoint: string, blocked: boolean) {
    this.metrics.totalRequests++;
    if (blocked) {
      this.metrics.blockedRequests++;
    }
    
    // 更新统计信息
    this.updateTopUsers(key);
    this.updateTopEndpoints(endpoint);
  }
  
  getMetrics(): RateLimitMetrics {
    return { ...this.metrics };
  }
  
  private updateTopUsers(key: string) {
    const existing = this.metrics.topUsers.find(u => u.key === key);
    if (existing) {
      existing.requests++;
    } else {
      this.metrics.topUsers.push({ key, requests: 1 });
    }
    
    // 保持前10名
    this.metrics.topUsers.sort((a, b) => b.requests - a.requests);
    this.metrics.topUsers = this.metrics.topUsers.slice(0, 10);
  }
  
  private updateTopEndpoints(endpoint: string) {
    const existing = this.metrics.topEndpoints.find(e => e.endpoint === endpoint);
    if (existing) {
      existing.requests++;
    } else {
      this.metrics.topEndpoints.push({ endpoint, requests: 1 });
    }
    
    // 保持前10名
    this.metrics.topEndpoints.sort((a, b) => b.requests - a.requests);
    this.metrics.topEndpoints = this.metrics.topEndpoints.slice(0, 10);
  }
}

export const rateLimitMonitor = new RateLimitMonitor();
```

## 配置参数

### 环境变量
```bash
# .env.local
RATE_LIMIT_ENABLED=true
RATE_LIMIT_STORAGE=memory  # memory | redis
REDIS_URL=redis://localhost:6379  # 如果使用Redis
RATE_LIMIT_LOG_LEVEL=info
RATE_LIMIT_ALERT_THRESHOLD=1000  # 每小时超过此数量触发告警
```

### 默认限制配置
```json
{
  "default": {
    "windowMs": 900000,
    "maxRequests": 100
  },
  "fileDownload": {
    "windowMs": 60000,
    "maxRequests": 10
  },
  "imageAccess": {
    "windowMs": 60000,
    "maxRequests": 30
  },
  "dataOperation": {
    "windowMs": 60000,
    "maxRequests": 60
  },
  "admin": {
    "windowMs": 900000,
    "maxRequests": 1000
  }
}
```

## 风险评估

### 技术风险
1. **性能影响**: 速率限制检查可能增加响应时间
   - **缓解措施**: 使用高效算法，考虑异步处理
2. **内存使用**: 内存存储可能占用大量内存
   - **缓解措施**: 实施LRU清理，考虑Redis存储
3. **误封**: 正常用户可能被误判为滥用
   - **缓解措施**: 设置合理的限制阈值，提供申诉机制

### 业务风险
1. **用户体验**: 限制过严可能影响正常使用
   - **缓解措施**: 基于用户行为调整限制策略
2. **API可用性**: 限制逻辑错误可能导致API不可用
   - **缓解措施**: 充分的测试，监控告警

## 成功指标

### 安全指标
- [ ] API滥用事件减少90%以上
- [ ] 服务器资源使用率降低20%
- [ ] 异常请求检测准确率达到95%以上

### 性能指标
- [ ] 速率限制检查延迟 < 5ms
- [ ] 正常用户请求成功率 > 99.9%
- [ ] 系统可用性 > 99.9%

### 监控指标
- [ ] 实时监控覆盖率100%
- [ ] 告警响应时间 < 5分钟
- [ ] 监控数据准确率 > 99%

## 时间计划

| 阶段 | 时间 | 主要交付物 |
|------|------|------------|
| 阶段一 | 3-5天 | 基础速率限制框架 |
| 阶段二 | 2-3天 | API端点集成完成 |
| 阶段三 | 2天 | 监控告警系统 |
| 阶段四 | 1-2天 | 测试部署完成 |
| **总计** | **8-12天** | **完整API速率限制系统** |

## 资源需求

### 开发资源
- 后端开发工程师: 1人
- 安全工程师: 0.5人
- 测试工程师: 0.5人

### 技术资源
- Redis服务器（可选）
- 监控工具
- 测试环境

## 后续优化方向

1. **智能限制**: 基于用户行为的动态限制调整
2. **分布式限制**: 支持多服务器部署的分布式限制
3. **机器学习**: 使用ML检测异常请求模式
4. **白名单管理**: 更精细的白名单和黑名单管理

---

**文档版本**: v1.0  
**创建日期**: 2024年12月  
**最后更新**: 2024年12月  
**负责人**: 安全团队
