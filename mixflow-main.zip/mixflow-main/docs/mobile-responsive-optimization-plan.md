# 移动端响应式优化开发计划 (FUNC-001)

## 项目概述

**需求ID**: FUNC-001  
**标题**: 添加移动端响应式优化  
**优先级**: P0 (Must - 基本型)  
**RICE得分**: 8.5  
**关键依据**: 移动端用户占比60%，基础体验要求

## 技术背景分析

### 当前状态
- 使用 Next.js 14.0.4 + Tailwind CSS
- 已有基础的响应式设计（lg:、md:、sm:断点）
- 侧边栏在移动端使用固定定位和滑动效果
- 模态框已适配移动端（底部弹出）
- 部分组件存在移动端体验问题

### 移动端问题识别
1. **布局问题**: 部分页面在小屏幕上布局不佳
2. **交互体验**: 触摸操作和手势支持不足
3. **性能问题**: 移动端加载和渲染性能待优化
4. **PWA体验**: 虽然配置了PWA，但移动端体验可进一步优化

### 现有响应式实现分析
- ✅ 侧边栏：已实现移动端滑动效果
- ✅ 模态框：已适配移动端底部弹出
- ✅ 基础布局：使用Tailwind响应式类
- ❌ 触摸手势：缺乏手势支持
- ❌ 移动端导航：导航体验待优化
- ❌ 移动端编辑器：编辑器在移动端体验不佳

## 开发计划

### 阶段一：核心布局优化 (1-2周)

#### 1.1 主布局响应式优化
**目标**: 优化主要页面的移动端布局

**任务清单**:
- [ ] 优化主页网格布局（统计卡片、清单列表）
- [ ] 改进看板视图的移动端显示
- [ ] 优化笔记编辑器的移动端布局
- [ ] 改进用户资料页面的移动端显示

**涉及文件**:
- `app/_components/features/home/components/Home.tsx`
- `app/_components/features/checklists/tasks/KanbanBoard.tsx`
- `app/_components/features/notes/components/UnifiedMarkdownRenderer.tsx`
- `app/_components/features/profile/UserProfileClient.tsx`

#### 1.2 导航和侧边栏优化
**目标**: 提升移动端导航体验

**任务清单**:
- [ ] 优化侧边栏在移动端的滑动体验
- [ ] 改进顶部导航栏的移动端显示
- [ ] 添加移动端专用的快捷操作
- [ ] 优化搜索功能在移动端的使用

**涉及文件**:
- `app/_components/common/layout/sidebar/Sidebar.tsx`
- `app/_components/features/header/QuickNav.tsx`
- `app/_components/common/search/SearchBar.tsx`

### 阶段二：交互体验优化 (1周)

#### 2.1 触摸手势支持
**目标**: 添加移动端手势操作

**任务清单**:
- [ ] 实现滑动删除功能
- [ ] 添加下拉刷新
- [ ] 实现长按菜单
- [ ] 优化拖拽操作在移动端的体验

**新增文件**:
- `app/_components/ui/gestures/SwipeGesture.tsx`
- `app/_components/ui/gestures/LongPressGesture.tsx`
- `app/_utils/gesture-utils.ts`

#### 2.2 移动端专用组件
**目标**: 创建移动端优化的组件

**任务清单**:
- [ ] 创建移动端优化的按钮组件
- [ ] 实现移动端友好的输入组件
- [ ] 优化移动端模态框体验
- [ ] 创建移动端专用的操作面板

**新增文件**:
- `app/_components/ui/mobile/MobileButton.tsx`
- `app/_components/ui/mobile/MobileInput.tsx`
- `app/_components/ui/mobile/MobileActionSheet.tsx`

### 阶段三：编辑器移动端优化 (1周)

#### 3.1 富文本编辑器优化
**目标**: 优化移动端编辑体验

**任务清单**:
- [ ] 优化TipTap编辑器在移动端的工具栏
- [ ] 改进移动端键盘体验
- [ ] 优化移动端文本选择
- [ ] 添加移动端专用的编辑快捷方式

**涉及文件**:
- `app/_components/features/notes/components/UnifiedMarkdownRenderer.tsx`
- 相关编辑器组件

#### 3.2 清单编辑器优化
**目标**: 优化移动端清单编辑体验

**任务清单**:
- [ ] 优化移动端清单项编辑
- [ ] 改进移动端拖拽排序
- [ ] 优化移动端批量操作
- [ ] 添加移动端专用的清单操作

**涉及文件**:
- `app/_components/features/checklists/` 相关组件

### 阶段四：性能和PWA优化 (0.5周)

#### 4.1 移动端性能优化
**任务清单**:
- [ ] 优化移动端图片加载
- [ ] 实现移动端代码分割
- [ ] 优化移动端字体加载
- [ ] 添加移动端缓存策略

#### 4.2 PWA体验优化
**任务清单**:
- [ ] 优化PWA安装提示
- [ ] 改进离线体验
- [ ] 优化移动端启动画面
- [ ] 添加移动端专用图标

## 技术实现细节

### 1. 响应式布局优化

#### 主页网格布局优化
```typescript
// app/_components/features/home/components/Home.tsx
export function HomeView({ lists, onCreateModal, onSelectChecklist }: HomeViewProps) {
  return (
    <div className="max-w-7xl mx-auto p-4 lg:p-8">
      {/* 移动端优化的标题区域 */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 sm:mb-8">
        <div className="text-center sm:text-left">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-2">
            Welcome Back
          </h1>
          <p className="text-base sm:text-lg text-muted-foreground">
            Your most recently updated checklists
          </p>
        </div>
        <Button 
          onClick={onCreateModal} 
          size="lg"
          className="w-full sm:w-auto"
        >
          <Plus className="h-5 w-5 mr-2" />
          New Checklist
        </Button>
      </div>

      {/* 移动端优化的统计卡片 */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6 sm:mb-8">
        <StatsCard
          icon={<Folder className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />}
          header="Total Lists"
          value={lists.length}
          className="text-sm sm:text-base"
        />
        {/* 其他统计卡片 */}
      </div>

      {/* 移动端优化的清单列表 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
        {lists.map((list) => (
          <ChecklistCard
            key={list.id}
            checklist={list}
            onClick={() => onSelectChecklist(list.id)}
            className="w-full"
          />
        ))}
      </div>
    </div>
  );
}
```

#### 看板视图移动端优化
```typescript
// app/_components/features/checklists/tasks/KanbanBoard.tsx
export function KanbanBoard({ checklist, onUpdate }: KanbanBoardProps) {
  return (
    <div className="flex-1 overflow-hidden pb-[6em]">
      <div className="h-full">
        <DndContext onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
          {/* 移动端优化的列布局 */}
          <div className="h-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 p-2 sm:p-4 overflow-x-auto">
            {columns.map((column) => {
              const items = getItemsByStatus(column.status);
              return (
                <KanbanColumn
                  key={column.id}
                  id={column.id}
                  title={column.title}
                  items={items}
                  status={column.status}
                  checklistId={localChecklist.id}
                  onUpdate={refreshChecklist}
                  className="min-w-[280px] sm:min-w-0"
                />
              );
            })}
          </div>
        </DndContext>
      </div>
    </div>
  );
}
```

### 2. 触摸手势实现

#### 滑动删除组件
```typescript
// app/_components/ui/gestures/SwipeGesture.tsx
interface SwipeGestureProps {
  children: React.ReactNode;
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  onSwipeUp?: () => void;
  onSwipeDown?: () => void;
  threshold?: number;
  className?: string;
}

export function SwipeGesture({
  children,
  onSwipeLeft,
  onSwipeRight,
  onSwipeUp,
  onSwipeDown,
  threshold = 50,
  className = ""
}: SwipeGestureProps) {
  const [startPos, setStartPos] = useState<{ x: number; y: number } | null>(null);
  const [currentPos, setCurrentPos] = useState<{ x: number; y: number } | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    setStartPos({ x: touch.clientX, y: touch.clientY });
    setCurrentPos({ x: touch.clientX, y: touch.clientY });
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    setCurrentPos({ x: touch.clientX, y: touch.clientY });
  };

  const handleTouchEnd = () => {
    if (!startPos || !currentPos) return;

    const deltaX = currentPos.x - startPos.x;
    const deltaY = currentPos.y - startPos.y;

    if (Math.abs(deltaX) > Math.abs(deltaY)) {
      // 水平滑动
      if (Math.abs(deltaX) > threshold) {
        if (deltaX > 0 && onSwipeRight) {
          onSwipeRight();
        } else if (deltaX < 0 && onSwipeLeft) {
          onSwipeLeft();
        }
      }
    } else {
      // 垂直滑动
      if (Math.abs(deltaY) > threshold) {
        if (deltaY > 0 && onSwipeDown) {
          onSwipeDown();
        } else if (deltaY < 0 && onSwipeUp) {
          onSwipeUp();
        }
      }
    }

    setStartPos(null);
    setCurrentPos(null);
  };

  return (
    <div
      className={className}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {children}
    </div>
  );
}
```

#### 长按手势组件
```typescript
// app/_components/ui/gestures/LongPressGesture.tsx
interface LongPressGestureProps {
  children: React.ReactNode;
  onLongPress: () => void;
  duration?: number;
  className?: string;
}

export function LongPressGesture({
  children,
  onLongPress,
  duration = 500,
  className = ""
}: LongPressGestureProps) {
  const [isPressed, setIsPressed] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleTouchStart = () => {
    setIsPressed(true);
    timeoutRef.current = setTimeout(() => {
      onLongPress();
      setIsPressed(false);
    }, duration);
  };

  const handleTouchEnd = () => {
    setIsPressed(false);
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
  };

  const handleTouchMove = () => {
    setIsPressed(false);
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
  };

  return (
    <div
      className={`${className} ${isPressed ? 'scale-95' : 'scale-100'} transition-transform`}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onTouchMove={handleTouchMove}
    >
      {children}
    </div>
  );
}
```

### 3. 移动端专用组件

#### 移动端操作面板
```typescript
// app/_components/ui/mobile/MobileActionSheet.tsx
interface MobileActionSheetProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  actions: Array<{
    label: string;
    icon?: React.ReactNode;
    onClick: () => void;
    variant?: 'default' | 'destructive';
  }>;
}

export function MobileActionSheet({
  isOpen,
  onClose,
  title,
  actions
}: MobileActionSheetProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 lg:hidden">
      {/* 背景遮罩 */}
      <div 
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
      />
      
      {/* 操作面板 */}
      <div className="absolute bottom-0 left-0 right-0 bg-background rounded-t-xl p-4 pb-safe">
        {/* 拖拽指示器 */}
        <div className="w-12 h-1.5 bg-muted-foreground/20 rounded-full mx-auto mb-4" />
        
        {title && (
          <h3 className="text-lg font-semibold text-foreground mb-4 text-center">
            {title}
          </h3>
        )}
        
        <div className="space-y-2">
          {actions.map((action, index) => (
            <button
              key={index}
              onClick={() => {
                action.onClick();
                onClose();
              }}
              className={cn(
                "w-full flex items-center gap-3 p-4 rounded-lg text-left transition-colors",
                action.variant === 'destructive'
                  ? "text-destructive hover:bg-destructive/10"
                  : "text-foreground hover:bg-accent"
              )}
            >
              {action.icon && (
                <div className="flex-shrink-0">
                  {action.icon}
                </div>
              )}
              <span className="font-medium">{action.label}</span>
            </button>
          ))}
        </div>
        
        <button
          onClick={onClose}
          className="w-full mt-4 p-4 rounded-lg bg-muted hover:bg-muted/80 text-foreground font-medium"
        >
          取消
        </button>
      </div>
    </div>
  );
}
```

### 4. 移动端样式优化

#### Tailwind配置扩展
```javascript
// tailwind.config.js
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      // 添加移动端专用断点
      screens: {
        'xs': '475px',
        'sm': '640px',
        'md': '768px',
        'lg': '1024px',
        'xl': '1280px',
        '2xl': '1536px',
      },
      // 添加移动端专用间距
      spacing: {
        'safe-top': 'env(safe-area-inset-top)',
        'safe-bottom': 'env(safe-area-inset-bottom)',
        'safe-left': 'env(safe-area-inset-left)',
        'safe-right': 'env(safe-area-inset-right)',
      },
      // 添加移动端专用字体大小
      fontSize: {
        'xs': ['0.75rem', { lineHeight: '1rem' }],
        'sm': ['0.875rem', { lineHeight: '1.25rem' }],
        'base': ['1rem', { lineHeight: '1.5rem' }],
        'lg': ['1.125rem', { lineHeight: '1.75rem' }],
        'xl': ['1.25rem', { lineHeight: '1.75rem' }],
        '2xl': ['1.5rem', { lineHeight: '2rem' }],
        '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
        '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
      },
      colors: {
        // 现有颜色配置...
      },
    },
  },
  plugins: [],
}
```

#### 移动端专用CSS
```css
/* app/_styles/mobile.css */
@layer utilities {
  /* 移动端安全区域支持 */
  .pb-safe {
    padding-bottom: env(safe-area-inset-bottom);
  }
  
  .pt-safe {
    padding-top: env(safe-area-inset-top);
  }
  
  .pl-safe {
    padding-left: env(safe-area-inset-left);
  }
  
  .pr-safe {
    padding-right: env(safe-area-inset-right);
  }
  
  /* 移动端触摸优化 */
  .touch-manipulation {
    touch-action: manipulation;
  }
  
  .touch-pan-x {
    touch-action: pan-x;
  }
  
  .touch-pan-y {
    touch-action: pan-y;
  }
  
  /* 移动端滚动优化 */
  .scroll-smooth-mobile {
    -webkit-overflow-scrolling: touch;
    scroll-behavior: smooth;
  }
  
  /* 移动端文本选择优化 */
  .select-text-mobile {
    -webkit-user-select: text;
    -moz-user-select: text;
    -ms-user-select: text;
    user-select: text;
  }
  
  /* 移动端按钮优化 */
  .btn-mobile {
    min-height: 44px;
    min-width: 44px;
    touch-action: manipulation;
  }
  
  /* 移动端输入框优化 */
  .input-mobile {
    font-size: 16px; /* 防止iOS缩放 */
    -webkit-appearance: none;
    border-radius: 0;
  }
}
```

### 5. 移动端性能优化

#### 图片懒加载优化
```typescript
// app/_components/ui/mobile/LazyImage.tsx
interface LazyImageProps {
  src: string;
  alt: string;
  className?: string;
  placeholder?: string;
}

export function LazyImage({ src, alt, className, placeholder }: LazyImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isInView, setIsInView] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (imgRef.current) {
      observer.observe(imgRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div ref={imgRef} className={className}>
      {isInView && (
        <img
          src={src}
          alt={alt}
          onLoad={() => setIsLoaded(true)}
          className={`transition-opacity duration-300 ${
            isLoaded ? 'opacity-100' : 'opacity-0'
          }`}
          loading="lazy"
        />
      )}
      {!isLoaded && placeholder && (
        <div className="absolute inset-0 bg-muted animate-pulse" />
      )}
    </div>
  );
}
```

## 配置参数

### 移动端断点配置
```typescript
// app/_utils/responsive-config.ts
export const BREAKPOINTS = {
  xs: '475px',
  sm: '640px',
  md: '768px',
  lg: '1024px',
  xl: '1280px',
  '2xl': '1536px',
} as const;

export const MOBILE_CONFIG = {
  // 移动端专用配置
  touchTargetSize: 44, // 最小触摸目标尺寸
  gestureThreshold: 50, // 手势识别阈值
  longPressDuration: 500, // 长按持续时间
  swipeThreshold: 100, // 滑动阈值
  
  // 性能配置
  lazyLoadThreshold: 0.1, // 懒加载阈值
  imageQuality: 0.8, // 图片质量
  animationDuration: 300, // 动画持续时间
} as const;
```

## 风险评估

### 技术风险
1. **兼容性问题**: 不同移动设备的兼容性差异
   - **缓解措施**: 充分测试主流设备和浏览器
2. **性能影响**: 手势和动画可能影响性能
   - **缓解措施**: 使用硬件加速，优化动画性能
3. **用户体验**: 过度优化可能影响桌面端体验
   - **缓解措施**: 渐进式优化，保持桌面端功能完整

### 业务风险
1. **开发周期**: 移动端优化可能延长开发时间
   - **缓解措施**: 分阶段实施，优先核心功能
2. **维护成本**: 移动端专用代码增加维护成本
   - **缓解措施**: 建立组件库，统一维护

## 成功指标

### 用户体验指标
- [ ] 移动端页面加载时间 < 3秒
- [ ] 移动端交互响应时间 < 100ms
- [ ] 移动端用户满意度 > 4.5/5
- [ ] 移动端跳出率降低20%

### 技术指标
- [ ] 移动端兼容性覆盖率 > 95%
- [ ] 移动端性能评分 > 90
- [ ] 移动端可访问性评分 > 90
- [ ] PWA安装率提升50%

### 业务指标
- [ ] 移动端用户活跃度提升30%
- [ ] 移动端用户留存率提升25%
- [ ] 移动端转化率提升20%

## 时间计划

| 阶段 | 时间 | 主要交付物 |
|------|------|------------|
| 阶段一 | 1-2周 | 核心布局优化完成 |
| 阶段二 | 1周 | 交互体验优化完成 |
| 阶段三 | 1周 | 编辑器移动端优化完成 |
| 阶段四 | 0.5周 | 性能和PWA优化完成 |
| **总计** | **3.5-4.5周** | **完整移动端响应式优化** |

## 资源需求

### 开发资源
- 前端开发工程师: 1人
- UI/UX设计师: 0.5人
- 测试工程师: 0.5人

### 测试资源
- 多种移动设备测试
- 不同浏览器兼容性测试
- 性能测试工具

## 后续优化方向

1. **原生应用**: 考虑开发React Native应用
2. **离线功能**: 增强PWA离线体验
3. **推送通知**: 添加移动端推送功能
4. **生物识别**: 集成指纹/面部识别登录

---

**文档版本**: v1.0  
**创建日期**: 2024年12月  
**最后更新**: 2024年12月  
**负责人**: 前端团队
