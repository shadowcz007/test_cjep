"use client";

import { Users, FileText, Activity, Shield } from "lucide-react";
import { Button } from "@/app/_components/ui/elements/button";
import { cn } from "@/app/_utils/utils";

type AdminTab = "overview" | "users" | "content" | "sharing";

interface AdminTabsProps {
  activeTab: AdminTab;
  onTabChange: (tab: AdminTab) => void;
}

export function AdminTabs({ activeTab, onTabChange }: AdminTabsProps) {
  const tabs = [
    {
      id: "overview" as AdminTab,
      label: "Overview",
      icon: Activity,
      shortLabel: "View",
    },
    {
      id: "users" as AdminTab,
      label: "Users",
      icon: Users,
      shortLabel: "Users",
    },
    {
      id: "content" as AdminTab,
      label: "Content",
      icon: FileText,
      shortLabel: "Content",
    },
    {
      id: "sharing" as AdminTab,
      label: "Sharing",
      icon: Shield,
      shortLabel: "Share",
    },
  ];

  return (
    <div className="bg-muted p-1 rounded-lg">
      <div className="flex space-x-1 overflow-x-auto scrollbar-hide">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <Button
              key={tab.id}
              variant={isActive ? "default" : "ghost"}
              size="sm"
              onClick={() => onTabChange(tab.id)}
              className={cn(
                "flex items-center gap-1 sm:gap-2 flex-shrink-0 min-w-0",
                "px-2 sm:px-3 py-2",
                isActive
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Icon className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
              <span className="truncate">
                <span className="hidden xs:inline sm:inline">{tab.label}</span>
                <span className="xs:hidden sm:hidden">{tab.shortLabel}</span>
              </span>
            </Button>
          );
        })}
      </div>
    </div>
  );
}
