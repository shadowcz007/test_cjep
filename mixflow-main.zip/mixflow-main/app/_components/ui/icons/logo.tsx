"use client";

export function Logo({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <svg
      width="100"
      height="100"
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* 背景圆形 */}
      <circle
        cx="50"
        cy="50"
        r="45"
        className="fill-current opacity-10"
      />
      
      {/* 主要流动线条 - 体现Flow概念 */}
      <path
        d="M20 30 Q35 20, 50 35 T80 30"
        className="stroke-current"
        strokeWidth="4"
        strokeLinecap="round"
        fill="none"
        opacity="0.8"
      />
      
      {/* 次要流动线条 - 体现Mix概念 */}
      <path
        d="M25 50 Q40 40, 55 55 T85 50"
        className="stroke-current"
        strokeWidth="3"
        strokeLinecap="round"
        fill="none"
        opacity="0.6"
      />
      
      {/* 第三条流动线条 - 增加层次感 */}
      <path
        d="M30 70 Q45 60, 60 75 T90 70"
        className="stroke-current"
        strokeWidth="2.5"
        strokeLinecap="round"
        fill="none"
        opacity="0.4"
      />
      
      {/* 中心点 - 体现聚焦和连接 */}
      <circle
        cx="50"
        cy="50"
        r="3"
        className="fill-current"
      />
      
      {/* 装饰性小点 - 体现清单项目 */}
      <circle
        cx="25"
        cy="35"
        r="2"
        className="fill-current"
        opacity="0.7"
      />
      <circle
        cx="75"
        cy="65"
        r="2"
        className="fill-current"
        opacity="0.7"
      />
    </svg>
  );
}
