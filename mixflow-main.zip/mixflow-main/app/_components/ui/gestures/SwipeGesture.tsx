"use client";

import { useState, useRef } from "react";
import { GestureUtils, TouchPosition, GESTURE_CONFIG } from "@/app/_utils/gesture-utils";

interface SwipeGestureProps {
  children: React.ReactNode;
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  onSwipeUp?: () => void;
  onSwipeDown?: () => void;
  threshold?: number;
  className?: string;
  disabled?: boolean;
}

export function SwipeGesture({
  children,
  onSwipeLeft,
  onSwipeRight,
  onSwipeUp,
  onSwipeDown,
  threshold = GESTURE_CONFIG.SWIPE_THRESHOLD,
  className = "",
  disabled = false
}: SwipeGestureProps) {
  const [startPos, setStartPos] = useState<TouchPosition | null>(null);
  const [currentPos, setCurrentPos] = useState<TouchPosition | null>(null);
  const startTimeRef = useRef<number>(0);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (disabled) return;

    const touch = e.touches[0];
    const pos = GestureUtils.getTouchPosition(touch);
    setStartPos(pos);
    setCurrentPos(pos);
    startTimeRef.current = Date.now();
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (disabled || !startPos) return;

    const touch = e.touches[0];
    setCurrentPos(GestureUtils.getTouchPosition(touch));
  };

  const handleTouchEnd = () => {
    if (disabled || !startPos || !currentPos) {
      setStartPos(null);
      setCurrentPos(null);
      return;
    }

    const endTime = Date.now();
    const duration = endTime - startTimeRef.current;

    const swipeDirection = GestureUtils.detectSwipe(startPos, currentPos, {
      threshold,
      direction: 'both'
    });

    switch (swipeDirection) {
      case 'left':
        onSwipeLeft?.();
        break;
      case 'right':
        onSwipeRight?.();
        break;
      case 'up':
        onSwipeUp?.();
        break;
      case 'down':
        onSwipeDown?.();
        break;
    }

    setStartPos(null);
    setCurrentPos(null);
  };

  return (
    <div
      className={className}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {children}
    </div>
  );
}
