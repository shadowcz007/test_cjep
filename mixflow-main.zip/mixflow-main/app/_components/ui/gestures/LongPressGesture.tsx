"use client";

import { useState, useRef } from "react";
import { GESTURE_CONFIG } from "@/app/_utils/gesture-utils";

interface LongPressGestureProps {
  children: React.ReactNode;
  onLongPress: () => void;
  duration?: number;
  className?: string;
  disabled?: boolean;
}

export function LongPressGesture({
  children,
  onLongPress,
  duration = GESTURE_CONFIG.LONG_PRESS_DURATION,
  className = "",
  disabled = false
}: LongPressGestureProps) {
  const [isPressed, setIsPressed] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const startPosRef = useRef<{ x: number; y: number } | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (disabled) return;

    const touch = e.touches[0];
    startPosRef.current = { x: touch.clientX, y: touch.clientY };
    setIsPressed(true);

    timeoutRef.current = setTimeout(() => {
      onLongPress();
      setIsPressed(false);
    }, duration);
  };

  const handleTouchEnd = () => {
    setIsPressed(false);
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!startPosRef.current || !timeoutRef.current) return;

    const touch = e.touches[0];
    const currentPos = { x: touch.clientX, y: touch.clientY };
    const deltaX = Math.abs(currentPos.x - startPosRef.current.x);
    const deltaY = Math.abs(currentPos.y - startPosRef.current.y);

    // 如果移动距离太大，取消长按
    if (deltaX > 10 || deltaY > 10) {
      setIsPressed(false);
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    }
  };

  return (
    <div
      className={`${className} ${isPressed ? 'scale-95' : 'scale-100'} transition-transform touch-manipulation`}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onTouchMove={handleTouchMove}
    >
      {children}
    </div>
  );
}
