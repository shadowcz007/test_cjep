"use client";

import { forwardRef } from "react";
import { Button, ButtonProps } from "@/app/_components/ui/elements/button";
import { cn } from "@/app/_utils/utils";

interface MobileButtonProps extends Omit<ButtonProps, 'size'> {
  size?: 'sm' | 'default' | 'lg' | 'xl';
}

export const MobileButton = forwardRef<HTMLButtonElement, MobileButtonProps>(
  ({ className, size = 'default', ...props }, ref) => {
    const sizeClasses = {
      sm: 'h-9 px-3 text-sm min-h-[36px]',
      default: 'h-11 px-4 text-base min-h-[44px]',
      lg: 'h-12 px-6 text-lg min-h-[48px]',
      xl: 'h-14 px-8 text-xl min-h-[52px]',
    };

    return (
      <Button
        ref={ref}
        className={cn(
          'touch-manipulation select-none',
          sizeClasses[size],
          className
        )}
        {...props}
      />
    );
  }
);

MobileButton.displayName = 'MobileButton';
