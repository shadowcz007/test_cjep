"use client";

import { useEffect } from "react";
import { cn } from "@/app/_utils/utils";

interface MobileActionSheetProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  actions: Array<{
    label: string;
    icon?: React.ReactNode;
    onClick: () => void;
    variant?: 'default' | 'destructive';
  }>;
}

export function MobileActionSheet({
  isOpen,
  onClose,
  title,
  actions
}: MobileActionSheetProps) {
  // 处理ESC键关闭
  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      // 防止页面滚动
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 lg:hidden">
      {/* 背景遮罩 */}
      <div
        className="absolute inset-0 bg-black/50 transition-opacity"
        onClick={onClose}
      />

      {/* 操作面板 */}
      <div className="absolute bottom-0 left-0 right-0 bg-background rounded-t-xl p-4 pb-safe animate-in slide-in-from-bottom duration-300">
        {/* 拖拽指示器 */}
        <div className="w-12 h-1.5 bg-muted-foreground/20 rounded-full mx-auto mb-4" />

        {title && (
          <h3 className="text-lg font-semibold text-foreground mb-4 text-center">
            {title}
          </h3>
        )}

        <div className="space-y-2">
          {actions.map((action, index) => (
            <button
              key={index}
              onClick={() => {
                action.onClick();
                onClose();
              }}
              className={cn(
                "w-full flex items-center gap-3 p-4 rounded-lg text-left transition-colors touch-manipulation",
                action.variant === 'destructive'
                  ? "text-destructive hover:bg-destructive/10 active:bg-destructive/20"
                  : "text-foreground hover:bg-accent active:bg-accent/80"
              )}
            >
              {action.icon && (
                <div className="flex-shrink-0">
                  {action.icon}
                </div>
              )}
              <span className="font-medium">{action.label}</span>
            </button>
          ))}
        </div>

        <button
          onClick={onClose}
          className="w-full mt-4 p-4 rounded-lg bg-muted hover:bg-muted/80 active:bg-muted/60 text-foreground font-medium touch-manipulation"
        >
          取消
        </button>
      </div>
    </div>
  );
}
