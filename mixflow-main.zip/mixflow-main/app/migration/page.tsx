import { MigrationPage } from "@/app/_components/features/migration/MigrationPage";

export default function Migration() {
  return <MigrationPage />;
}
