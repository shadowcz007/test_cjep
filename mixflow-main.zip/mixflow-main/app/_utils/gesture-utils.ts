export interface TouchPosition {
  x: number;
  y: number;
}

export interface SwipeGestureConfig {
  threshold?: number;
  velocityThreshold?: number;
  direction?: 'horizontal' | 'vertical' | 'both';
}

export class GestureUtils {
  static getTouchPosition(touch: Touch | React.Touch): TouchPosition {
    return {
      x: touch.clientX,
      y: touch.clientY,
    };
  }

  static getDistance(start: TouchPosition, end: TouchPosition): number {
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    return Math.sqrt(dx * dx + dy * dy);
  }

  static getDirection(start: TouchPosition, end: TouchPosition): 'up' | 'down' | 'left' | 'right' {
    const dx = end.x - start.x;
    const dy = end.y - start.y;

    if (Math.abs(dx) > Math.abs(dy)) {
      return dx > 0 ? 'right' : 'left';
    } else {
      return dy > 0 ? 'down' : 'up';
    }
  }

  static getVelocity(start: TouchPosition, end: TouchPosition, duration: number): number {
    const distance = this.getDistance(start, end);
    return distance / duration; // pixels per millisecond
  }

  static detectSwipe(
    startPos: TouchPosition,
    endPos: TouchPosition,
    config: SwipeGestureConfig = {}
  ): 'left' | 'right' | 'up' | 'down' | null {
    const {
      threshold = 50,
      velocityThreshold = 0.3,
      direction = 'both'
    } = config;

    const deltaX = endPos.x - startPos.x;
    const deltaY = endPos.y - startPos.y;
    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);

    // 检查是否超过阈值
    if (absX < threshold && absY < threshold) {
      return null;
    }

    // 检查速度
    const velocity = this.getVelocity(startPos, endPos, 100); // 假设100ms
    if (velocity < velocityThreshold) {
      return null;
    }

    // 根据方向限制确定滑动方向
    if (direction === 'horizontal' && absY > absX) {
      return null;
    }

    if (direction === 'vertical' && absX > absY) {
      return null;
    }

    if (absX > absY) {
      return deltaX > 0 ? 'right' : 'left';
    } else {
      return deltaY > 0 ? 'down' : 'up';
    }
  }
}

export const GESTURE_CONFIG = {
  SWIPE_THRESHOLD: 50,
  VELOCITY_THRESHOLD: 0.3,
  LONG_PRESS_DURATION: 500,
  DOUBLE_TAP_DELAY: 300,
} as const;
