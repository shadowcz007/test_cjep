// 移动端性能优化工具

export const MOBILE_PERFORMANCE_CONFIG = {
  // 图片优化配置
  imageQuality: 0.8,
  lazyLoadThreshold: 0.1,

  // 动画优化配置
  animationDuration: 300,
  reducedMotion: false,

  // 字体加载优化
  fontDisplay: 'swap' as const,

  // 缓存配置
  cacheStrategy: 'network-first' as const,
} as const;

export class MobilePerformanceUtils {
  /**
   * 检查是否支持WebP格式
   */
  static supportsWebP(): Promise<boolean> {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      canvas.width = 1;
      canvas.height = 1;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(false);
        return;
      }

      const imageData = ctx.createImageData(1, 1);
      const img = new Image();

      img.onload = () => {
        ctx.drawImage(img, 0, 0);
        const result = ctx.getImageData(0, 0, 1, 1).data;
        resolve(result[0] !== 0);
      };

      img.onerror = () => resolve(false);
      img.src = 'data:image/webp;base64,UklGRiQAAABXRUJQVlA4IBgAAAAwAQCdASoBAAEAAwA0JaQAA3AA/vuUAAA=';
    });
  }

  /**
   * 获取设备像素比优化的图片URL
   */
  static getOptimizedImageUrl(url: string, quality: number = MOBILE_PERFORMANCE_CONFIG.imageQuality): string {
    if (typeof window === 'undefined') return url;

    const urlObj = new URL(url);
    const devicePixelRatio = Math.min(window.devicePixelRatio, 2); // 限制最大倍数为2

    urlObj.searchParams.set('q', Math.floor(quality * 100).toString());
    urlObj.searchParams.set('dpr', devicePixelRatio.toString());

    return urlObj.toString();
  }

  /**
   * 检测是否是移动设备
   */
  static isMobileDevice(): boolean {
    if (typeof window === 'undefined') return false;

    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
      navigator.userAgent
    ) || window.innerWidth <= 768;
  }

  /**
   * 检测是否支持触摸事件
   */
  static supportsTouch(): boolean {
    if (typeof window === 'undefined') return false;

    return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
  }

  /**
   * 检测是否启用了减少动画
   */
  static prefersReducedMotion(): boolean {
    if (typeof window === 'undefined') return false;

    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }

  /**
   * 获取连接质量
   */
  static getConnectionQuality(): 'slow' | 'fast' {
    if (typeof navigator === 'undefined') return 'fast';

    const connection = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;

    if (!connection) return 'fast';

    const effectiveType = connection.effectiveType;
    return effectiveType === 'slow-2g' || effectiveType === '2g' ? 'slow' : 'fast';
  }

  /**
   * 预加载关键资源
   */
  static preloadCriticalResources(resources: string[]): void {
    if (typeof document === 'undefined') return;

    resources.forEach(url => {
      const link = document.createElement('link');
      link.rel = 'preload';
      link.href = url;
      link.as = this.getResourceType(url);
      document.head.appendChild(link);
    });
  }

  private static getResourceType(url: string): string {
    const extension = url.split('.').pop()?.toLowerCase();

    switch (extension) {
      case 'css':
        return 'style';
      case 'js':
        return 'script';
      case 'woff':
      case 'woff2':
      case 'ttf':
        return 'font';
      default:
        return 'image';
    }
  }
}

// 移动端字体加载优化
export const MOBILE_FONT_CONFIG = {
  googleFontsUrl: 'https://fonts.googleapis.com/css2',
  fontDisplay: 'swap',
  preloadFonts: ['Inter:wght@400;500;600;700'],
} as const;
