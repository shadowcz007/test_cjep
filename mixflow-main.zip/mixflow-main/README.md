# mixflow

<p align="center">
  <a href="https://www.buymeacoffee.com/shadowcz007">
    <img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy me a coffee" width="150">
  </a>
</p>

一个简单、自托管的清单和笔记应用。

厌倦了臃肿的云端待办应用？`mixflow` 是一个轻量级的替代方案，用于管理您的个人清单和笔记。它基于 Next.js 14 构建，易于部署，并将所有数据保存在您自己的服务器上。
 
## 功能特性

- **清单管理：** 创建支持拖拽排序、进度条和分类的任务列表。支持简单清单和高级任务项目，包括看板和时间跟踪。
- **富文本笔记：** 基于 TipTap 的简洁所见即所得编辑器，支持完整的 Markdown 语法和代码高亮。
- **分享功能：** 与实例中的其他用户分享清单或笔记，包括可分享链接的公开分享。
- **基于文件：** 无需数据库！所有数据都存储在单个数据目录中的简单 Markdown 和 JSON 文件中。
- **用户管理：** 管理员面板，用于创建和管理用户账户，支持会话跟踪。
- **可定制：** 14 个内置主题，支持自定义主题、表情符号和图标。
- **API 访问：** 通过带身份验证的 REST API 程序化访问您的清单和笔记。

## 技术栈

- **框架：** Next.js 14 (App Router)
- **语言：** TypeScript
- **样式：** Tailwind CSS
- **状态管理：** Zustand
- **编辑器：** TipTap
- **拖拽：** @dnd-kit
- **部署：** Docker

## API

`mixflow` 包含一个 REST API，用于程序化访问您的清单和笔记。这非常适合：

- **自动化：** 从外部系统创建任务
- **集成：** 与其他工具和服务连接
- **脚本：** 自动化重复性任务
- **仪表板：** 构建自定义界面

📖 **完整的 API 文档，请查看 [app/api/README.md](app/api/README.md)**

## 部署

⚠️ **重要部署说明**

此项目**无法部署**到 Vercel、Netlify 或其他不提供持久文件系统访问的无服务器平台。`mixflow` 需要：

- **持久文件系统** 用于在 `data/` 目录中存储数据
- **写入权限** 用于创建和修改文件
- **基于文件的存储** 用于清单、笔记和用户数据

**推荐的部署选项：**
- **Docker**（推荐）
- **阿里云 (Alibaba Cloud)** - ECS云服务器
- **VPS/云服务器** 具有持久存储
- **传统主机** 具有文件系统访问权限

**不兼容的平台：**
- Vercel
- Netlify
- Railway（无持久卷）
- 其他无服务器平台

## 快速开始

推荐使用 Docker 运行 `mixflow`。

 
### 初始设置

首次访问时，您将被重定向到 `/auth/setup` 创建管理员账户。完成后，您就可以开始使用了！

### 本地开发（不使用 Docker）

如果您想在本地运行应用进行开发：

1.  **克隆和安装：**
    ```bash
    git clone <repository-url>
    cd mixflow
    npm install
    ```
2.  **运行开发服务器：**
    ```bash
    npm run dev
    ```
    应用将在 `http://localhost:3000` 运行。

## 数据存储

`mixflow` 在 `data/` 目录中使用简单的基于文件的存储系统。

- `data/checklists/`: 将所有清单存储为 `.md` 文件。
- `data/notes/`: 将所有笔记存储为 `.md` 文件。
- `data/users/`: 包含 `users.json` 和 `sessions.json`。
- `data/sharing/`: 包含 `shared-items.json`。

**请确保备份 `data` 目录！**

## 更新

### 手动更新

如果您从源码运行，请拉取最新更改并重新构建。

```bash
git pull
npm install
npm run build
npm start
```

## 自定义主题和表情符号

您可以通过在 `config/` 目录中创建配置文件来轻松添加自定义主题和表情符号。这些将自动加载并与内置主题和表情符号合并。

### 自定义主题

创建 `config/themes.json` 文件，包含您的自定义主题：

```json
{
  "custom-themes": {
    "my-theme": {
      "name": "My Custom Theme",
      "icon": "Palette",
      "colors": {
        "--background": "255 255 255",
        "--background-secondary": "249 250 251",
        "--foreground": "20 20 20",
        "--primary": "37 99 235",
        "--primary-foreground": "255 255 255",
        "--secondary": "241 245 249",
        "--secondary-foreground": "20 20 20",
        "--muted": "241 245 249",
        "--muted-foreground": "100 116 139",
        "--accent": "241 245 249",
        "--accent-foreground": "20 20 20",
        "--destructive": "239 68 68",
        "--destructive-foreground": "255 255 255",
        "--border": "226 232 240",
        "--input": "226 232 240",
        "--ring": "37 99 235"
      }
    }
  }
}
```

**必需的颜色变量：**

- `--background`, `--background-secondary`, `--foreground`
- `--card`, `--card-foreground`, `--popover`, `--popover-foreground`
- `--primary`, `--primary-foreground`, `--secondary`, `--secondary-foreground`
- `--muted`, `--muted-foreground`, `--accent`, `--accent-foreground`
- `--destructive`, `--destructive-foreground`, `--border`, `--input`, `--ring`

### 自定义表情符号

创建 `config/emojis.json` 文件，包含您的自定义表情符号：

```json
{
  "custom-emojis": {
    "meeting": "🤝",
    "deadline": "⏰",
    "project": "📋",
    "deploy": "🚀",
    "bug": "🐛",
    "feature": "✨"
  }
}
```

当您输入包含这些单词的清单项目时，自定义表情符号将自动出现。

### 可用图标

对于主题，您可以使用这些图标名称：`Sun`, `Moon`, `Sunset`, `Waves`, `Trees`, `CloudMoon`, `Palette`, `Terminal`, `Github`, `Monitor`, `Coffee`, `Flower2`, `Flame`, `Palmtree`, `Building`。如果未指定图标，将根据主题名称选择默认图标。

### 配置验证

应用会验证您的配置文件，如果存在格式错误，将在控制台中显示警告。无效的配置将被忽略，应用将继续使用内置主题和表情符号。

### 自定义配置的 Docker 设置

更新您的 `docker-compose.yml` 以包含配置卷：

```yaml
services:
  app:
    image: ghcr.io/shadowcz007/mixflow:main
    container_name: mixflow
    user: "1000:1000"
    ports:
      - "1122:3000"
    volumes:
      - ./data:/app/data:rw
      - ./config:/app/config:ro
    restart: unless-stopped
    environment:
      - NODE_ENV=production
      - HTTPS=false
    init: true
```

**重要：** 确保您的本地 `config/` 目录具有正确的权限：

```bash
mkdir -p config
chown -R 1000:1000 config/
chmod -R 755 config/
```

